package com.example.todolist;

import android.app.Activity;

public class MainActivity extends Activity {
}
